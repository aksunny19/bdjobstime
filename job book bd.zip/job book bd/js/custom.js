// init Isotope
var $grid = $('.portfolio_item').isotope({
    // options
  });
  // filter items on button click
  $('.menu_items').on( 'click', 'li', function() {
    var filterValue = $(this).attr('data-filter');
    $grid.isotope({ filter: filterValue });
  });
  // filter items on button active
  $('.menu_items').on( 'click', 'li', function() {
    $(this). addClass('active'). siblings(). removeClass('active');
  });


  //

  var typed = new Typed('.element', {
    strings: ['career'],
    loop:true,
      typeSpeed:200,
      backSpeed:200,
  });

  //
  $('.image-link').magnificPopup({type:'image',
  gallery:{
    enabled:true
}
});
$('.video').magnificPopup({type:'iframe'
 
});

//
$(window).load(function(){
    $(window).on('scroll', function(){
        if($(window).scrollTop() > 25){
            $('.nav_wrap').addClass('sticky');
        }
        else{
            $('.nav_wrap').removeClass('sticky');
        }
    })
});
//
$(window).load(function() {
    $('#slider').nivoSlider();
});

//

$(function (){
    $('.simple-marquee-container').SimpleMarquee();
        
    });

//

$(document).ready(function(){$('#menu').slicknav();});

//

$('.slide_area').owlCarousel({
    loop: true,
        margin: 10,
        items: 5,
        dots: false,
        nav: true,
        navText: ["<span class='fa fa-angle-left'><span/>", "<span class='fa fa-angle-right'><span/>"],
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        smartSpeed: 1200,
        autoHeight: false,
        autoplay: true,
        responsive: {

            0: {
                items: 1,
            },

            480: {
                items: 1,
            },

            768: {
                items: 3,
            },

            992: {
                items: 4,
            }
        }
});

//

$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle();
    });
});


//
new WOW().init();